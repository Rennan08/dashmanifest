import { useState, useEffect } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell, LineChart, Line } from 'recharts'
import { FileText, MapPin, Users, Calendar, Search, Filter, TrendingUp, AlertTriangle, LogOut, Shield, User } from 'lucide-react'
import '../App.css'

const Dashboard = ({ user, onLogout }) => {
  const [rawData, setRawData] = useState([])
  const [filteredData, setFilteredData] = useState([])
  const [filters, setFilters] = useState({
    search: '',
    month: 'all',
    municipality: 'all',
    organization: 'all',
    motive: 'all'
  })

  // Dados estáticos baseados na análise
  const summaryData = {
    totalManifestacoes: 156,
    municipiosEnvolvidos: 20,
    organizacoesAtivas: 79,
    periodoMeses: 5
  }

  const manifestacoesPorMes = [
    { mes: 'Janeiro', quantidade: 33, color: '#3b82f6' },
    { mes: 'Fevereiro', quantidade: 6, color: '#10b981' },
    { mes: 'Março', quantidade: 21, color: '#f59e0b' },
    { mes: 'Abril', quantidade: 65, color: '#ef4444' },
    { mes: 'Maio', quantidade: 31, color: '#8b5cf6' }
  ]

  const top10Municipios = [
    { municipio: 'BELÉM', quantidade: 70, color: '#3b82f6' },
    { municipio: 'ICOARACI', quantidade: 18, color: '#10b981' },
    { municipio: 'ITAITUBA', quantidade: 14, color: '#f59e0b' },
    { municipio: 'ANANINDEUA', quantidade: 11, color: '#ef4444' },
    { municipio: 'SANTARÉM', quantidade: 8, color: '#8b5cf6' },
    { municipio: 'ABAETETUBA', quantidade: 6, color: '#06b6d4' },
    { municipio: 'MARABÁ', quantidade: 6, color: '#84cc16' },
    { municipio: 'CASTANHAL', quantidade: 5, color: '#f97316' },
    { municipio: 'BOM JESUS DO TOCANTINS', quantidade: 2, color: '#ec4899' },
    { municipio: 'ALTAMIRA', quantidade: 2, color: '#6366f1' }
  ]

  const organizacoesPorTipo = [
    { tipo: 'SINTEPP', quantidade: 45, color: '#3b82f6' },
    { tipo: 'INDÍGENAS', quantidade: 38, color: '#10b981' },
    { tipo: 'PSOL', quantidade: 12, color: '#f59e0b' },
    { tipo: 'UNIDADE POPULAR', quantidade: 8, color: '#ef4444' },
    { tipo: 'OUTROS', quantidade: 53, color: '#8b5cf6' }
  ]

  const motivosPrincipais = [
    { motivo: 'Revogação da Lei 10.820', quantidade: 89, color: '#3b82f6' },
    { motivo: 'Greve dos Professores', quantidade: 34, color: '#10b981' },
    { motivo: 'Ato Político', quantidade: 23, color: '#f59e0b' },
    { motivo: 'Outros', quantidade: 10, color: '#ef4444' }
  ]

  const tendenciaTemporal = [
    { periodo: 'Jan', manifestacoes: 33, incidentes: 2 },
    { periodo: 'Fev', manifestacoes: 6, incidentes: 0 },
    { periodo: 'Mar', manifestacoes: 21, incidentes: 1 },
    { periodo: 'Abr', manifestacoes: 65, incidentes: 4 },
    { periodo: 'Mai', manifestacoes: 31, incidentes: 2 }
  ]

  useEffect(() => {
    // Simular carregamento de dados
    setRawData(manifestacoesPorMes)
    setFilteredData(manifestacoesPorMes)
  }, [])

  const handleFilterChange = (key, value) => {
    setFilters(prev => ({ ...prev, [key]: value }))
    
    // Aplicar filtros aos dados
    let filtered = [...manifestacoesPorMes]
    
    if (value !== 'all' && key === 'month') {
      filtered = filtered.filter(item => 
        item.mes.toLowerCase().includes(value.toLowerCase())
      )
    }
    
    setFilteredData(filtered)
  }

  const clearFilters = () => {
    setFilters({
      search: '',
      month: 'all',
      municipality: 'all',
      organization: 'all',
      motive: 'all'
    })
    setFilteredData(manifestacoesPorMes)
  }

  const getFilteredSummary = () => {
    const total = filteredData.reduce((sum, item) => sum + item.quantidade, 0)
    return {
      ...summaryData,
      totalManifestacoes: total
    }
  }

  const filteredSummary = getFilteredSummary()

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header com autenticação */}
      <div className="bg-white shadow-sm border-b">
        <div className="px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Shield className="h-8 w-8 text-blue-600" />
            <div>
              <h1 className="text-2xl font-bold text-gray-900">Dashboard de Manifestações 2025</h1>
              <p className="text-sm text-gray-600">Sistema de Inteligência de Segurança Pública</p>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 px-3 py-2 bg-blue-50 rounded-lg">
              <User className="h-4 w-4 text-blue-600" />
              <div className="text-sm">
                <div className="font-medium text-blue-900">{user.username}</div>
                <div className="text-blue-600">{user.role}</div>
              </div>
            </div>
            <Button 
              variant="outline" 
              size="sm" 
              onClick={onLogout}
              className="flex items-center gap-2"
            >
              <LogOut className="h-4 w-4" />
              Sair
            </Button>
          </div>
        </div>
      </div>

      <div className="p-6">
        {/* Subtítulo */}
        <div className="mb-8">
          <p className="text-gray-600">Análise interativa dos dados de manifestações (Atualizado até 22.05.2025)</p>
          <div className="mt-2 flex items-center gap-2 text-sm text-green-600">
            <div className="w-2 h-2 bg-green-500 rounded-full"></div>
            Sistema ativo - Dados em tempo real
          </div>
        </div>

        {/* Filtros */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Filter className="h-5 w-5" />
              Filtros de Análise
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 xl:grid-cols-5 gap-4">
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Busca Geral</label>
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                  <Input
                    placeholder="BELÉM"
                    value={filters.search}
                    onChange={(e) => handleFilterChange('search', e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Mês</label>
                <Select value={filters.month} onValueChange={(value) => handleFilterChange('month', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os meses" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os meses</SelectItem>
                    <SelectItem value="janeiro">Janeiro</SelectItem>
                    <SelectItem value="fevereiro">Fevereiro</SelectItem>
                    <SelectItem value="março">Março</SelectItem>
                    <SelectItem value="abril">Abril</SelectItem>
                    <SelectItem value="maio">Maio</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Município</label>
                <Select value={filters.municipality} onValueChange={(value) => handleFilterChange('municipality', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os municípios" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os municípios</SelectItem>
                    <SelectItem value="belem">BELÉM</SelectItem>
                    <SelectItem value="icoaraci">ICOARACI</SelectItem>
                    <SelectItem value="itaituba">ITAITUBA</SelectItem>
                    <SelectItem value="ananindeua">ANANINDEUA</SelectItem>
                    <SelectItem value="santarem">SANTARÉM</SelectItem>
                    <SelectItem value="abaetetuba">ABAETETUBA</SelectItem>
                    <SelectItem value="maraba">MARABÁ</SelectItem>
                    <SelectItem value="castanhal">CASTANHAL</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Organização</label>
                <Select value={filters.organization} onValueChange={(value) => handleFilterChange('organization', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todas as organizações" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todas as organizações</SelectItem>
                    <SelectItem value="sintepp">SINTEPP</SelectItem>
                    <SelectItem value="indigenas">INDÍGENAS</SelectItem>
                    <SelectItem value="psol">PSOL</SelectItem>
                    <SelectItem value="unidade_popular">UNIDADE POPULAR</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="text-sm font-medium text-gray-700 mb-2 block">Motivo</label>
                <Select value={filters.motive} onValueChange={(value) => handleFilterChange('motive', value)}>
                  <SelectTrigger>
                    <SelectValue placeholder="Todos os motivos" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">Todos os motivos</SelectItem>
                    <SelectItem value="lei">Revogação da Lei 10.820</SelectItem>
                    <SelectItem value="greve">Greve dos Professores</SelectItem>
                    <SelectItem value="politico">Ato Político</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            
            <div className="mt-4 flex justify-end">
              <Button variant="outline" onClick={clearFilters} className="flex items-center gap-2">
                <Filter className="h-4 w-4" />
                Limpar Filtros
              </Button>
            </div>
          </CardContent>
        </Card>

        {/* Cards de Resumo */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Total de Manifestações</p>
                  <p className="text-3xl font-bold text-gray-900">{filteredSummary.totalManifestacoes}</p>
                  <p className="text-xs text-gray-500 mt-1">Filtrado de 156 registros</p>
                </div>
                <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <FileText className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Municípios Envolvidos</p>
                  <p className="text-3xl font-bold text-gray-900">{summaryData.municipiosEnvolvidos}</p>
                  <p className="text-xs text-gray-500 mt-1">Diferentes localidades</p>
                </div>
                <div className="h-12 w-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <MapPin className="h-6 w-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Organizações Ativas</p>
                  <p className="text-3xl font-bold text-gray-900">{summaryData.organizacoesAtivas}</p>
                  <p className="text-xs text-gray-500 mt-1">Diferentes organizações</p>
                </div>
                <div className="h-12 w-12 bg-blue-100 rounded-lg flex items-center justify-center">
                  <Users className="h-6 w-6 text-blue-600" />
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">Período</p>
                  <p className="text-3xl font-bold text-gray-900">{summaryData.periodoMeses}</p>
                  <p className="text-xs text-gray-500 mt-1">Meses com atividade</p>
                </div>
                <div className="h-12 w-12 bg-red-100 rounded-lg flex items-center justify-center">
                  <Calendar className="h-6 w-6 text-red-600" />
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Gráficos Principais */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 mb-8">
          {/* Manifestações por Mês */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Manifestações por Mês
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={filteredData}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="mes" />
                  <YAxis />
                  <Tooltip />
                  <Bar dataKey="quantidade" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Top 10 Municípios */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <MapPin className="h-5 w-5" />
                Top 10 Municípios
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {top10Municipios.map((item, index) => (
                  <div key={item.municipio} className="flex items-center justify-between hover:bg-gray-50 p-2 rounded transition-colors">
                    <div className="flex items-center gap-3">
                      <div 
                        className="w-4 h-4 rounded"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="font-medium text-sm">{item.municipio}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div 
                        className="h-2 rounded-full transition-all duration-300"
                        style={{ 
                          backgroundColor: item.color,
                          width: `${(item.quantidade / 70) * 100}px`
                        }}
                      />
                      <span className="text-sm font-bold min-w-[20px]">{item.quantidade}</span>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Gráficos Adicionais */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 mb-8">
          {/* Organizações por Tipo */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <Users className="h-5 w-5" />
                Organizações por Tipo
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={organizacoesPorTipo}
                    cx="50%"
                    cy="50%"
                    outerRadius={80}
                    dataKey="quantidade"
                    label={({ tipo, quantidade }) => `${tipo}: ${quantidade}`}
                  >
                    {organizacoesPorTipo.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          {/* Motivos Principais */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertTriangle className="h-5 w-5" />
                Motivos Principais
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {motivosPrincipais.map((item, index) => (
                  <div key={item.motivo} className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <div 
                        className="w-3 h-3 rounded-full"
                        style={{ backgroundColor: item.color }}
                      />
                      <span className="text-xs font-medium">{item.motivo}</span>
                    </div>
                    <span className="text-sm font-bold">{item.quantidade}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Tendência Temporal */}
          <Card className="hover:shadow-lg transition-shadow">
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <TrendingUp className="h-5 w-5" />
                Tendência Temporal
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={tendenciaTemporal}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="periodo" />
                  <YAxis />
                  <Tooltip />
                  <Line 
                    type="monotone" 
                    dataKey="manifestacoes" 
                    stroke="#3b82f6" 
                    strokeWidth={3}
                    dot={{ fill: '#3b82f6', strokeWidth: 2, r: 4 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="incidentes" 
                    stroke="#ef4444" 
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={{ fill: '#ef4444', strokeWidth: 2, r: 3 }}
                  />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default Dashboard

